#project: P3
#submitter: shizmi
#partner: none

# data from: Kaggle.
# URL: https://www.kaggle.com/timoboz/superbowl-history-1967-2020

import pandas as pd
import csv, requests, re
from flask import Flask, request, jsonify

app = Flask(__name__)

counter = 0
a_counter = 0
b_counter = 0

@app.route('/')
def home():
    global a_counter
    global b_counter
    global counter
    
    # alternate between pages on first 10 visits
    if counter < 10:
        if counter % 2 == 0:
            with open("indexa.html") as f:
                html = f.read()
        else:
            with open("indexb.html") as f:
                html = f.read()
        counter += 1
    # after 10 visits choose best page to visit
    else:
        if a_counter > b_counter:
            with open("indexa.html") as f:
                html = f.read()
        else:
            with open("indexb.html") as f:
                html = f.read()    
    return html

# helper method for returning csv data in a list
def get_data():
    file = open("main.csv", encoding = "utf-8")
    reader = csv.reader(file)
    data = list(reader)
    file.close()
    return data

# helper method to make a row of the data into a dictionary
def make_dict(row):
    row_dict = {}
    data = get_data()
    header = data[0]
    for i in range(len(header)):
        row_dict[header[i]] = row[i]
    return row_dict

@app.route('/browse.html')
def browse_handler():
    df = pd.read_csv("main.csv")
    return "<h1> Browse </h1>" + df.to_html()

@app.route('/api.html')
def api_handler():
    txt1 = "To get one superbowl, do this: \n <pre>/superbowl.json?sb=30</pre> <br>"
    txt2 = "To get all superbowls, use this URL endpoint: \n <pre>/superbowls.json</pre> <br>"
    txt3 = "To get a combined scored superbowl, use this URL endpoint: \n <pre>/superbowls.json?scoring=40</pre> <br>"
    return "<h1> API </h1>" + txt1 + txt2 + txt3

@app.route('/superbowl.json', methods=["GET"])
def query():
    sb = request.args.get("sb")
    data = get_data()
    row = 0
    for i in range(len(data)):
        if sb == re.sub("[^0-9]", "", data[i][1]):
            row = i
    return jsonify(make_dict(data[row]))
    
@app.route('/superbowls.json', methods=["GET"])
def superbowls():
    data = get_data()
    list_of_dicts = []
    header = data[0]
    data = data[1:]
    if request.args.get("scoring") == None:
        for i in range(len(data)):
            sb_dict = {}
            for j in range(len(header)):
                sb_dict[header[j]] = data[i][j]
            list_of_dicts.append(sb_dict)
    else:
        scoring = request.args.get("scoring", type=int)
        for i in range(len(data)):
            scoring_dict = {}
            if int(data[i][3]) + int(data[i][5]) >= scoring:
                list_of_dicts.append(make_dict(data[i]))
    
    return jsonify(list_of_dicts)

@app.route('/donate.html', methods=["GET"])
def donate_handler():
    global a_counter
    global b_counter
    option = request.args.get('from', type=str)
    page = "<h1> Donate </h1>"
    if option == "A":
        a_counter += 1
    else:
        b_counter += 1
    return page
    
    
@app.route('/email', methods=["POST"])
def email():
    email = str(request.data, "utf-8")
    # regex got from here: https://emailregex.com/
    if re.match(r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)", email):
        with open("emails.txt", "a") as f: # open file in append mode
            f.write(email + '\n')
        return jsonify("thanks")
    return jsonify("DONT BE GIVIN ME DAT BAD EMAIL")
    
if __name__ == '__main__':
    app.run(host="0.0.0.0") # don't change this line!